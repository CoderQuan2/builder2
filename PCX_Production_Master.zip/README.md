# PCX // XENO-PAC 3D Tactical Arcade Engine

> **Production-Grade 3D Arcade Title & Android APK Build Architecture**  
> *Zero Fake CSS Filters • True WebGL 3D Geometry • Autonomous Quad-Ghost AI • Chrono-Singularity Meta-Economy • Codespaces & CI/CD Pipelines*

---

## 1. Architectural Philosophy: The "Zero-Filter" Mandate
Most retro revival engines slap a blurry scanline CSS filter or contrast overlay onto a flat 2D canvas. **PCX** deliberately rejects post-processing filter overlays in favor of real, crisp, hardware-accelerated 3D geometry and dynamic lighting:
* **Monolithic Cyber Corridors:** Extruded 3D bevelled walls with metallic reflections and cyan emissive circuitry.
* **Procedural Floor Grid:** Canvas-generated high-resolution metallic grid textures with micro-flecks and illuminated node coordinates (100% self-contained, no external PNGs).
* **Articulated 3D Pac-Sphere:** Dual-jaw mouth opening/closing chomp mechanics with directional optical headlights that project real-time light into the labyrinth corridors.
* **Autonomous Quad-Ghost AI:** Distinct 3D phantom models with undulating skirts, animated pupil kinematics that dynamically look toward their destination, and state machines for Chase, Scatter, Frightened, and House Exit.
* **Dynamic Action Camera Rig:** Switch seamlessly between:
  1. `CHASE`: Trailing 3rd-person camera with smooth velocity banking into turns.
  2. `TACTICAL`: 45-degree isometric arena overview.
  3. `AERIAL`: Classic clean top-down tactical grid.

---

## 2. Deep Gameplay & Physical Usability
* **Continuous Sub-Pixel Movement:** No choppy tile-snapping; entities move smoothly at deterministic velocity.
* **Precise Corner Buffering:** Inputs are buffered within a 0.38-tile window before intersections, guaranteeing immediate, responsive turns without sticking to walls.
* **Autonomous AI Archetypes:**
  * **Blinky (Red):** Direct Euclidean pursuit with Cruise Elroy speed acceleration as dots deplete.
  * **Pinky (Pink):** 4-tile forward predictive lead ambush.
  * **Inky (Cyan):** Flanker vector reflection across Blinky's coordinates.
  * **Clyde (Orange):** Territorial cowardice boundary (retreats to home corner when closer than 8 tiles).
* **High-Precision Procedural Audio Engine (`PCXAudioEngine`):** Pure polyphonic synthesis using Web Audio API:
  * Dual-phase alternating waka cadence with stereo panning.
  * Continuous multi-oscillator siren drone that scales pitch and modulation dynamically as dots decrease.
  * Sawtooth energizer rising sweep.
  * Ghost consumption crunch chime.
  * Death frequency collapse and Doppler rewind effects.
  * Zero external MP3/WAV dependencies; 100% offline and low-latency.

---

## 3. High-Conversion "Brain-Bending" Monetization (Chrono Singularity)
* **Timeline Collapse (Quantum Rewind):** When intercepted by a ghost, reality enters a 5-second decoherence freeze rather than an abrupt game over.
* **Singularity Shards:** Players can expend a Singularity Core/Shard to execute a high-speed reverse-time Doppler rewind, resetting the player and ghosts 4 seconds back into safe territory while preserving high-score momentum.
* **Meta-Economy:** Singularity Shards are earned through high-score milestones (every 5,000 points) or unlocked via cosmetic warp passes.

---

## 4. Directory Structure
```
PCX/
├── index.html                  # Modular development shell
├── build.js                    # Automated build script bundling assets for dist/
├── dist/
│   └── index.html              # Fully self-contained bundled production build
├── css/
│   └── style.css               # Clean cyberpunk HUD, responsive mobile D-Pad
├── js/
│   ├── audio.js                # Web Audio API procedural synthesizer
│   ├── textures.js             # Canvas procedural texture generators
│   ├── map.js                  # 28x31 Maze grid, BFS reachability, tunnel wrap
│   ├── particles.js            # 3D particle emitter pool (bursts, shockwaves)
│   ├── entities.js             # Pac-Man & Quad Ghost 3D meshes & AI
│   ├── renderer.js             # Three.js scene, lighting, camera controller
│   └── game.js                 # Game loop, corner buffering, rewind ring buffer
├── package.json                # npm dependencies, build scripts
├── capacitor.config.json       # Android native wrapper configuration
├── setup-and-build.sh          # Headless Codespaces / Linux APK compiler
├── .github/
│   └── workflows/
│       └── build-apk.yml       # GitHub Actions automated CI/CD pipeline
└── README.md                   # Complete architectural guide
```

---

## 5. One-Touch Codespaces / Remote Linux Build
Compile directly into an installable Android APK inside **GitHub Codespaces** or any Ubuntu/Debian environment without Android Studio:

```bash
chmod +x setup-and-build.sh
./setup-and-build.sh
```

Compiled native binary output:
`android/app/build/outputs/apk/debug/app-debug.apk`
