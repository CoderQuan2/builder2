const fs = require('fs');
const path = require('path');

const distDir = path.join(__dirname, 'dist');
if (!fs.existsSync(distDir)) {
  fs.mkdirSync(distDir, { recursive: true });
}

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (let entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

copyDir(path.join(__dirname, 'css'), path.join(distDir, 'css'));
copyDir(path.join(__dirname, 'js'), path.join(distDir, 'js'));

let html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
const css = fs.readFileSync(path.join(__dirname, 'css', 'style.css'), 'utf8');

html = html.replace('<link rel="stylesheet" href="css/style.css">', `<style>\n${css}\n</style>`);

const jsModules = ['audio.js', 'textures.js', 'map.js', 'particles.js', 'entities.js', 'renderer.js', 'game.js'];
let bundledJs = '';
for (const mod of jsModules) {
  const content = fs.readFileSync(path.join(__dirname, 'js', mod), 'utf8');
  bundledJs += `\n/* --- ${mod} --- */\n` + content + '\n';
}

const startMarker = '<script src="js/audio.js"></script>';
const endMarker = '<script src="js/game.js"></script>';
const startIndex = html.indexOf(startMarker);
const endIndex = html.indexOf(endMarker) + endMarker.length;

if (startIndex !== -1 && endIndex !== -1) {
  html = html.substring(0, startIndex) + `<script>\n${bundledJs}\n</script>` + html.substring(endIndex);
}

fs.writeFileSync(path.join(distDir, 'index.html'), html);
console.log('✔ Built PCX/dist with both bundled index.html and modular assets.');
