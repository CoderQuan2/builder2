/* ==============================================================================
   PCX // High-Performance 3D Particle Systems
   Emitters for dot eating, energizer shockwaves, and rewind vortex.
   ============================================================================== */
class PCXParticleEngine {
  constructor(scene) {
    this.scene = scene;
    this.particles = [];

    this.dotParticleGeo = new THREE.SphereGeometry(0.08, 6, 6);
    this.cyanMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
    this.amberMat = new THREE.MeshBasicMaterial({ color: 0xf59e0b });
    this.purpleMat = new THREE.MeshBasicMaterial({ color: 0xc084fc });
  }

  spawnBurst(x, y, z, colorType = 'cyan', count = 8) {
    const mat = colorType === 'amber' ? this.amberMat : (colorType === 'purple' ? this.purpleMat : this.cyanMat);
    for (let i = 0; i < count; i++) {
      const mesh = new THREE.Mesh(this.dotParticleGeo, mat);
      mesh.position.set(x, y, z);
      this.scene.add(mesh);

      const theta = Math.random() * Math.PI * 2;
      const speed = 0.04 + Math.random() * 0.08;
      this.particles.push({
        mesh,
        vx: Math.cos(theta) * speed,
        vy: 0.04 + Math.random() * 0.06,
        vz: Math.sin(theta) * speed,
        life: 1.0,
        decay: 0.035 + Math.random() * 0.02
      });
    }
  }

  update(dtFactor) {
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.mesh.position.x += p.vx * dtFactor;
      p.mesh.position.y += p.vy * dtFactor;
      p.mesh.position.z += p.vz * dtFactor;
      p.vy -= 0.003 * dtFactor;
      p.life -= p.decay * dtFactor;
      p.mesh.scale.setScalar(Math.max(0.01, p.life));

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        this.particles.splice(i, 1);
      }
    }
  }

  clear() {
    this.particles.forEach(p => this.scene.remove(p.mesh));
    this.particles = [];
  }
}
