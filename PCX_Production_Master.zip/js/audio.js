/* ==============================================================================
   PCX // Audio Engine: High-Precision Procedural Polyphony & Dynamic Spatial DSP
   Zero audio file dependencies. 100% synthetic, low-latency Web Audio API.
   ============================================================================== */
class PCXAudioEngine {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.sirenNode = null;
    this.sirenGain = null;
    this.filterNode = null;
    this.muted = false;
    this.lastWakaTime = 0;
    this.wakaPhase = false;
  }

  init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) {
        this.ctx = new AC();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);

        this.filterNode = this.ctx.createBiquadFilter();
        this.filterNode.type = 'lowpass';
        this.filterNode.frequency.setValueAtTime(18000, this.ctx.currentTime);

        this.filterNode.connect(this.masterGain);
        this.masterGain.connect(this.ctx.destination);

        this._initContinuousSiren();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  _initContinuousSiren() {
    if (!this.ctx || this.sirenNode) return;
    this.sirenNode = this.ctx.createOscillator();
    this.sirenGain = this.ctx.createGain();
    this.sirenNode.type = 'triangle';
    this.sirenNode.frequency.setValueAtTime(115, this.ctx.currentTime);
    this.sirenGain.gain.setValueAtTime(0.0001, this.ctx.currentTime);

    this.sirenNode.connect(this.sirenGain);
    this.sirenGain.connect(this.filterNode);
    this.sirenNode.start();
  }

  toggleMute() {
    this.init();
    this.muted = !this.muted;
    if (this.masterGain) {
      this.masterGain.gain.setTargetAtTime(this.muted ? 0.0 : 0.8, this.ctx.currentTime, 0.05);
    }
    return this.muted;
  }

  updateSiren(active, isFrightened, dotRatio = 1.0) {
    if (!this.ctx || !this.sirenGain || this.muted) return;
    const now = this.ctx.currentTime;
    if (!active) {
      this.sirenGain.gain.setTargetAtTime(0.0001, now, 0.08);
      return;
    }

    const speedMultiplier = 1.0 + (1.0 - Math.min(1.0, dotRatio)) * 0.8;
    const baseFreq = isFrightened ? 160 : (120 * speedMultiplier);
    const modFreq = isFrightened ? 8 : (3 * speedMultiplier);
    const modAmp = isFrightened ? 45 : (25 * speedMultiplier);

    const freq = baseFreq + Math.sin(now * modFreq) * modAmp;
    this.sirenNode.frequency.setValueAtTime(freq, now);
    this.sirenGain.gain.setTargetAtTime(0.035, now, 0.05);
  }

  playWaka(playerX = 0) {
    if (!this.ctx || this.muted) return;
    const now = this.ctx.currentTime;
    if (now - this.lastWakaTime < 0.085) return;
    this.lastWakaTime = now;
    this.wakaPhase = !this.wakaPhase;

    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';

    const f1 = this.wakaPhase ? 330 : 255;
    const f2 = this.wakaPhase ? 255 : 330;
    osc.frequency.setValueAtTime(f1, now);
    osc.frequency.exponentialRampToValueAtTime(f2, now + 0.075);

    gain.gain.setValueAtTime(0.14, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.075);

    if (this.ctx.createStereoPanner) {
      const panner = this.ctx.createStereoPanner();
      panner.pan.value = Math.max(-0.8, Math.min(0.8, playerX / 14));
      osc.connect(gain);
      gain.connect(panner);
      panner.connect(this.filterNode);
    } else {
      osc.connect(gain);
      gain.connect(this.filterNode);
    }

    osc.start(now);
    osc.stop(now + 0.075);
  }

  playEnergizer() {
    if (!this.ctx || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(140, now);
    osc.frequency.linearRampToValueAtTime(880, now + 0.28);
    gain.gain.setValueAtTime(0.2, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.28);

    osc.connect(gain);
    gain.connect(this.filterNode);
    osc.start(now);
    osc.stop(now + 0.28);
  }

  playGhostEaten() {
    if (!this.ctx || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'square';
    osc.frequency.setValueAtTime(920, now);
    osc.frequency.exponentialRampToValueAtTime(110, now + 0.38);
    gain.gain.setValueAtTime(0.28, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.38);

    osc.connect(gain);
    gain.connect(this.filterNode);
    osc.start(now);
    osc.stop(now + 0.38);
  }

  playDeath() {
    if (!this.ctx || this.muted) return;
    const now = this.ctx.currentTime;
    const notes = [587.33, 554.37, 523.25, 493.88, 466.16, 440.00, 415.30, 392.00, 349.23, 311.13, 261.63, 196.00];
    notes.forEach((f, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      const t = now + idx * 0.062;
      osc.frequency.setValueAtTime(f, t);
      osc.frequency.exponentialRampToValueAtTime(f * 0.85, t + 0.058);
      gain.gain.setValueAtTime(0.2, t);
      gain.gain.linearRampToValueAtTime(0.001, t + 0.058);

      osc.connect(gain);
      gain.connect(this.filterNode);
      osc.start(t);
      osc.stop(t + 0.058);
    });
  }

  playDopplerRewind() {
    if (!this.ctx || this.muted) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(60, now);
    osc.frequency.exponentialRampToValueAtTime(1400, now + 0.65);
    gain.gain.setValueAtTime(0.35, now);
    gain.gain.linearRampToValueAtTime(0.001, now + 0.65);

    osc.connect(gain);
    gain.connect(this.filterNode);
    osc.start(now);
    osc.stop(now + 0.65);
  }
}
