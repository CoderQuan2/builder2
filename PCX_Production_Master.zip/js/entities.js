/* ==============================================================================
   PCX // Entity State Machines & 3D Articulated Meshes
   Pac-Man articulated chomp & Quad Autonomous Ghost AI with eye kinematics.
   ============================================================================== */
class PCXEntityManager {
  static createPlayerMesh() {
    const group = new THREE.Group();
    const playerMat = new THREE.MeshStandardMaterial({
      color: 0xffd000,
      emissive: 0xffaa00,
      emissiveIntensity: 0.5,
      roughness: 0.2,
      metalness: 0.75
    });

    const upperJaw = new THREE.Mesh(new THREE.SphereGeometry(0.72, 32, 16, 0, Math.PI * 2, 0, Math.PI / 2), playerMat);
    const lowerJaw = new THREE.Mesh(new THREE.SphereGeometry(0.72, 32, 16, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), playerMat);
    upperJaw.castShadow = true;
    lowerJaw.castShadow = true;
    group.add(upperJaw);
    group.add(lowerJaw);

    const light = new THREE.PointLight(0xffea00, 2.5, 14);
    light.position.set(0, 0.6, 0);
    group.add(light);

    group.upperJaw = upperJaw;
    group.lowerJaw = lowerJaw;
    return group;
  }

  static createGhostMesh(colorHex) {
    const group = new THREE.Group();
    const bodyMat = new THREE.MeshStandardMaterial({
      color: colorHex,
      emissive: colorHex,
      emissiveIntensity: 0.55,
      roughness: 0.3,
      metalness: 0.5
    });

    const dome = new THREE.Mesh(new THREE.SphereGeometry(0.68, 24, 16, 0, Math.PI * 2, 0, Math.PI / 2), bodyMat);
    const skirt = new THREE.Mesh(new THREE.CylinderGeometry(0.68, 0.72, 0.6, 24, 1, true), bodyMat);
    skirt.position.y = -0.3;
    dome.castShadow = true;
    skirt.castShadow = true;
    group.add(dome);
    group.add(skirt);

    const eyeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x090d16 });

    const leftEye = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), eyeMat);
    leftEye.position.set(-0.25, 0.15, 0.55);
    const rightEye = new THREE.Mesh(new THREE.SphereGeometry(0.18, 12, 12), eyeMat);
    rightEye.position.set(0.25, 0.15, 0.55);

    const leftPupil = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), pupilMat);
    leftPupil.position.set(-0.25, 0.15, 0.68);
    const rightPupil = new THREE.Mesh(new THREE.SphereGeometry(0.09, 8, 8), pupilMat);
    rightPupil.position.set(0.25, 0.15, 0.68);

    group.add(leftEye);
    group.add(rightEye);
    group.add(leftPupil);
    group.add(rightPupil);

    group.bodyMat = bodyMat;
    group.originalColor = colorHex;
    group.leftPupil = leftPupil;
    group.rightPupil = rightPupil;
    return group;
  }
}
