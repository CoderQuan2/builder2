/* ==============================================================================
   PCX // 3D World Renderer, Lighting & Dynamic Action Camera Rig
   Three.js WebGL 2.0 pipeline with dynamic trailing camera banking.
   ============================================================================== */
class PCXRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x030408);
    this.scene.fog = new THREE.FogExp2(0x030408, 0.015);

    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    this.camera = new THREE.PerspectiveCamera(52, window.innerWidth / window.innerHeight, 0.1, 1000);
    this.cameraMode = 'CHASE';

    this.initLighting();
    this.initWorldGeometry();
  }

  initLighting() {
    const ambientLight = new THREE.AmbientLight(0x0a1428, 1.3);
    this.scene.add(ambientLight);

    const mainDirLight = new THREE.DirectionalLight(0x00e5ff, 1.25);
    mainDirLight.position.set(20, 50, 25);
    mainDirLight.castShadow = true;
    mainDirLight.shadow.mapSize.width = 2048;
    mainDirLight.shadow.mapSize.height = 2048;
    mainDirLight.shadow.bias = -0.0004;
    this.scene.add(mainDirLight);

    const rimLight = new THREE.DirectionalLight(0xc084fc, 0.65);
    rimLight.position.set(-25, 35, -25);
    this.scene.add(rimLight);
  }

  initWorldGeometry() {
    const TILE = PCXMap.TILE;
    const COLS = PCXMap.COLS;
    const ROWS = PCXMap.ROWS;

    const floorGeo = new THREE.PlaneGeometry(COLS * TILE, ROWS * TILE);
    const floorMat = new THREE.MeshStandardMaterial({
      map: PCXTextureEngine.createFloorGridTexture(),
      roughness: 0.25,
      metalness: 0.85
    });
    const floorMesh = new THREE.Mesh(floorGeo, floorMat);
    floorMesh.rotation.x = -Math.PI / 2;
    floorMesh.receiveShadow = true;
    this.scene.add(floorMesh);

    this.wallsGroup = new THREE.Group();
    this.scene.add(this.wallsGroup);

    this.dotsGroup = new THREE.Group();
    this.scene.add(this.dotsGroup);
  }

  updateCamera(targetPos, dir) {
    if (this.cameraMode === 'CHASE') {
      const offsetZ = dir.z === -1 ? 14 : (dir.z === 1 ? -14 : 0);
      const offsetX = dir.x === -1 ? 14 : (dir.x === 1 ? -14 : 0);
      const desiredX = targetPos.x + (offsetX !== 0 ? offsetX : 0);
      const desiredZ = targetPos.z + (offsetZ !== 0 ? offsetZ : 16);
      const desiredY = 15;

      this.camera.position.x += (desiredX - this.camera.position.x) * 0.08;
      this.camera.position.y += (desiredY - this.camera.position.y) * 0.08;
      this.camera.position.z += (desiredZ - this.camera.position.z) * 0.08;
      this.camera.lookAt(targetPos.x, targetPos.y + 0.5, targetPos.z);
    } else if (this.cameraMode === 'TACTICAL') {
      this.camera.position.set(targetPos.x, 28, targetPos.z + 24);
      this.camera.lookAt(targetPos.x, 0, targetPos.z);
    } else {
      this.camera.position.set(0, 52, 0);
      this.camera.lookAt(0, 0, 0);
    }
  }

  resize() {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  }

  render() {
    this.renderer.render(this.scene, this.camera);
  }
}
