/* ==============================================================================
   PCX // Master Game Engine
   Sub-pixel continuous physics, corner buffering, Chrono Rewind ring buffer.
   ============================================================================== */
class PCXGame {
  constructor() {
    this.canvas = document.getElementById('webgl-canvas');
    this.renderer = new PCXRenderer(this.canvas);
    this.audio = new PCXAudioEngine();
    this.map = new PCXMap();
    this.particles = new PCXParticleEngine(this.renderer.scene);

    this.gameState = 'START';
    this.score = 0;
    this.highScore = parseInt(localStorage.getItem('pcx_highscore') || '10000');
    this.lives = 3;
    this.singularityShards = 1;
    this.level = 1;
    this.frightenedTimer = 0;

    this.timelineHistory = [];
    this.MAX_HISTORY = 240;

    this.initMazeMeshes();
    this.initEntities();
    this.initInput();
    this.initUI();

    window.addEventListener('resize', () => this.renderer.resize());
    this.lastTime = performance.now();
    requestAnimationFrame((t) => this.loop(t));
  }

  initMazeMeshes() {
    const TILE = PCXMap.TILE;
    const COLS = PCXMap.COLS;
    const ROWS = PCXMap.ROWS;

    const wallGeo = new THREE.BoxGeometry(TILE * 0.98, 1.8, TILE * 0.98);
    const wallMat = new THREE.MeshStandardMaterial({
      color: 0x111928,
      roughness: 0.3,
      metalness: 0.8,
      emissive: 0x002d38,
      emissiveIntensity: 0.35
    });

    const dotGeo = new THREE.SphereGeometry(0.2, 12, 12);
    const dotMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      emissive: 0x00e5ff,
      emissiveIntensity: 0.8,
      roughness: 0.1
    });

    const energizerGeo = new THREE.OctahedronGeometry(0.55, 0);
    const energizerMat = new THREE.MeshStandardMaterial({
      color: 0xffaa00,
      emissive: 0xff8800,
      emissiveIntensity: 1.2,
      roughness: 0.1,
      metalness: 0.9
    });

    this.dots = [];
    for (let r = 0; r < ROWS; r++) {
      for (let c = 0; c < COLS; c++) {
        const val = this.map.grid[r][c];
        const posX = (c - COLS / 2 + 0.5) * TILE;
        const posZ = (r - ROWS / 2 + 0.5) * TILE;

        if (val === 1) {
          const wall = new THREE.Mesh(wallGeo, wallMat);
          wall.position.set(posX, 0.9, posZ);
          wall.castShadow = true;
          wall.receiveShadow = true;
          this.renderer.wallsGroup.add(wall);
        } else if (val === 0 || val === 2) {
          const isEnergizer = (val === 2);
          const mesh = new THREE.Mesh(isEnergizer ? energizerGeo : dotGeo, isEnergizer ? energizerMat : dotMat);
          mesh.position.set(posX, isEnergizer ? 0.6 : 0.3, posZ);
          mesh.castShadow = isEnergizer;
          this.renderer.dotsGroup.add(mesh);
          this.dots.push({ mesh, r, c, isEnergizer, active: true });
        }
      }
    }
  }

  initEntities() {
    this.playerMesh = PCXEntityManager.createPlayerMesh();
    this.renderer.scene.add(this.playerMesh);

    this.player = {
      x: 13.5,
      z: 23.0,
      dir: { x: -1, z: 0 },
      bufferDir: { x: -1, z: 0 },
      speed: 0.105,
      mouthAnim: 0
    };

    const ghostColors = [0xef4444, 0xf472b6, 0x06b6d4, 0xf97316];
    const ghostConfigs = [
      { name: 'Blinky', startX: 13.5, startZ: 11, homeCorner: { x: 26, z: 1 } },
      { name: 'Pinky',  startX: 13.5, startZ: 14, homeCorner: { x: 1, z: 1 } },
      { name: 'Inky',   startX: 11.5, startZ: 14, homeCorner: { x: 26, z: 29 } },
      { name: 'Clyde',  startX: 15.5, startZ: 14, homeCorner: { x: 1, z: 29 } }
    ];

    this.ghosts = ghostConfigs.map((cfg, idx) => {
      const mesh = PCXEntityManager.createGhostMesh(ghostColors[idx]);
      this.renderer.scene.add(mesh);
      return {
        ...cfg,
        id: idx,
        mesh,
        x: cfg.startX,
        z: cfg.startZ,
        dir: { x: 0, z: -1 },
        speed: 0.088,
        state: idx === 0 ? 'CHASE' : 'HOUSE',
        frightenedTimer: 0,
        houseTimer: idx * 120
      };
    });
  }

  initInput() {
    window.addEventListener('keydown', (e) => {
      const k = e.key;
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' ', 'w', 'a', 's', 'd', 'W', 'A', 'S', 'D', 'c', 'C'].includes(k)) {
        e.preventDefault();
      }
      this.audio.init();

      if (k === ' ' && this.gameState === 'START') this.startGame();
      if (k === 'c' || k === 'C') this.toggleCamera();

      if (k === 'ArrowUp' || k === 'w' || k === 'W') this.player.bufferDir = { x: 0, z: -1 };
      if (k === 'ArrowDown' || k === 's' || k === 'S') this.player.bufferDir = { x: 0, z: 1 };
      if (k === 'ArrowLeft' || k === 'a' || k === 'A') this.player.bufferDir = { x: -1, z: 0 };
      if (k === 'ArrowRight' || k === 'd' || k === 'D') this.player.bufferDir = { x: 1, z: 0 };
    });

    const bindTouch = (id, dir) => {
      const btn = document.getElementById(id);
      if (!btn) return;
      const act = (e) => {
        e.preventDefault();
        this.audio.init();
        if (this.gameState === 'START') this.startGame();
        this.player.bufferDir = dir;
      };
      btn.addEventListener('pointerdown', act);
      btn.addEventListener('touchstart', act, { passive: false });
    };

    bindTouch('pad-up', { x: 0, z: -1 });
    bindTouch('pad-down', { x: 0, z: 1 });
    bindTouch('pad-left', { x: -1, z: 0 });
    bindTouch('pad-right', { x: 1, z: 0 });
  }

  initUI() {
    document.getElementById('btn-start').addEventListener('click', () => this.startGame());
    document.getElementById('btn-camera').addEventListener('click', () => this.toggleCamera());
    document.getElementById('btn-sound').addEventListener('click', () => {
      const isMuted = this.audio.toggleMute();
      document.getElementById('btn-sound').innerText = isMuted ? 'AUDIO: OFF' : 'AUDIO: ON';
    });

    document.getElementById('btn-accept-rewind').addEventListener('click', () => this.executeRewind());
    document.getElementById('btn-decline-rewind').addEventListener('click', () => this.declineRewind());
    this.updateHUD();
  }

  toggleCamera() {
    if (this.renderer.cameraMode === 'CHASE') this.renderer.cameraMode = 'TACTICAL';
    else if (this.renderer.cameraMode === 'TACTICAL') this.renderer.cameraMode = 'AERIAL';
    else this.renderer.cameraMode = 'CHASE';
    document.getElementById('btn-camera').innerText = `CAM: ${this.renderer.cameraMode} [C]`;
  }

  startGame() {
    this.audio.init();
    if (this.gameState === 'GAMEOVER') {
      this.score = 0;
      this.lives = 3;
      this.level = 1;
      this.singularityShards = 1;
      this.dots.forEach(d => { d.active = true; d.mesh.visible = true; });
      this.resetEntities();
    } else if (this.gameState === 'LEVEL_CLEAR') {
      this.level++;
      this.dots.forEach(d => { d.active = true; d.mesh.visible = true; });
      this.resetEntities();
    }
    this.gameState = 'RUNNING';
    document.getElementById('center-banner').style.display = 'none';
    this.updateHUD();
  }

  updatePlayerPhysics(dtFactor) {
    const step = this.player.speed * dtFactor;
    const tileX = Math.round(this.player.x);
    const tileZ = Math.round(this.player.z);

    if (this.player.z >= 13.5 && this.player.z <= 14.5) {
      if (this.player.x < -0.5) this.player.x = PCXMap.COLS - 0.5;
      if (this.player.x > PCXMap.COLS - 0.5) this.player.x = -0.5;
    }

    const buffering = (this.player.bufferDir.x !== this.player.dir.x || this.player.bufferDir.z !== this.player.dir.z);
    if (buffering) {
      if (this.player.bufferDir.x !== 0 && Math.abs(this.player.z - tileZ) < 0.38) {
        if (!this.map.isBlocked(tileX + this.player.bufferDir.x, tileZ)) {
          this.player.z = tileZ;
          this.player.dir = { ...this.player.bufferDir };
        }
      } else if (this.player.bufferDir.z !== 0 && Math.abs(this.player.x - tileX) < 0.38) {
        if (!this.map.isBlocked(tileX, tileZ + this.player.bufferDir.z)) {
          this.player.x = tileX;
          this.player.dir = { ...this.player.bufferDir };
        }
      }
    }

    const lookX = Math.round(this.player.x + this.player.dir.x * 0.52);
    const lookZ = Math.round(this.player.z + this.player.dir.z * 0.52);
    if (this.map.isBlocked(lookX, lookZ)) {
      this.player.x = tileX;
      this.player.z = tileZ;
    } else {
      this.player.x += this.player.dir.x * step;
      this.player.z += this.player.dir.z * step;
      this.player.mouthAnim += dtFactor * 0.38;
      this.audio.playWaka(this.player.x - 14);
    }

    const worldX = (this.player.x - PCXMap.COLS / 2 + 0.5) * PCXMap.TILE;
    const worldZ = (this.player.z - PCXMap.ROWS / 2 + 0.5) * PCXMap.TILE;
    this.playerMesh.position.set(worldX, 0.72, worldZ);

    let angle = 0;
    if (this.player.dir.x === 1) angle = 0;
    else if (this.player.dir.x === -1) angle = Math.PI;
    else if (this.player.dir.z === 1) angle = Math.PI / 2;
    else if (this.player.dir.z === -1) angle = -Math.PI / 2;
    this.playerMesh.rotation.y = -angle;

    const mouth = Math.abs(Math.sin(this.player.mouthAnim)) * 0.65;
    this.playerMesh.upperJaw.rotation.z = mouth;
    this.playerMesh.lowerJaw.rotation.z = -mouth;

    this.dots.forEach(d => {
      if (d.active && Math.hypot(this.player.x - d.c, this.player.z - d.r) < 0.65) {
        d.active = false;
        d.mesh.visible = false;
        this.score += d.isEnergizer ? 50 : 10;
        this.particles.spawnBurst(worldX, 0.5, worldZ, d.isEnergizer ? 'amber' : 'cyan', d.isEnergizer ? 16 : 6);

        if (this.score > this.highScore) {
          this.highScore = this.score;
          localStorage.setItem('pcx_highscore', this.highScore);
        }

        if (d.isEnergizer) {
          this.frightenedTimer = 380;
          this.audio.playEnergizer();
          this.ghosts.forEach(g => {
            if (g.state !== 'HOUSE') {
              g.frightenedTimer = 380;
              g.mesh.bodyMat.color.setHex(0x1d4ed8);
              g.mesh.bodyMat.emissive.setHex(0x3b82f6);
            }
          });
        }
        this.updateHUD();
        this.checkVictory();
      }
    });
  }

  updateGhostAI(dtFactor) {
    if (this.frightenedTimer > 0) {
      this.frightenedTimer -= dtFactor;
      if (this.frightenedTimer <= 0) {
        this.ghosts.forEach(g => {
          g.mesh.bodyMat.color.setHex(g.originalColor);
          g.mesh.bodyMat.emissive.setHex(g.originalColor);
        });
      }
    }

    this.ghosts.forEach(g => {
      if (g.state === 'HOUSE') {
        g.houseTimer -= dtFactor;
        g.z = 14 + Math.sin(Date.now() * 0.005 + g.id) * 0.25;
        if (g.houseTimer <= 0) g.state = 'EXITING';
      } else if (g.state === 'EXITING') {
        if (Math.abs(g.x - 13.5) > 0.05) g.x += Math.sign(13.5 - g.x) * 0.05 * dtFactor;
        else {
          g.x = 13.5;
          g.z -= 0.05 * dtFactor;
          if (g.z <= 11.0) {
            g.z = 11.0;
            g.state = 'CHASE';
            g.dir = { x: -1, z: 0 };
          }
        }
      } else {
        const speed = (g.frightenedTimer > 0) ? g.speed * 0.55 : g.speed;
        const step = speed * dtFactor;
        const tileX = Math.round(g.x);
        const tileZ = Math.round(g.z);

        if (Math.hypot(g.x - tileX, g.z - tileZ) < step * 0.95) {
          g.x = tileX;
          g.z = tileZ;

          const cx = Math.sign(g.dir.x), cz = Math.sign(g.dir.z);
          const valid = [
            { x: 0, z: -1 }, { x: -1, z: 0 }, { x: 0, z: 1 }, { x: 1, z: 0 }
          ].filter(d => {
            if (d.x === -cx && d.z === -cz && (cx !== 0 || cz !== 0)) return false;
            return !this.map.isBlocked(tileX + d.x, tileZ + d.z, true);
          });

          if (valid.length > 0) {
            let target = { x: this.player.x, z: this.player.z };
            if (g.frightenedTimer > 0) {
              target = g.homeCorner;
            } else if (g.id === 1) {
              target = { x: this.player.x + this.player.dir.x * 4, z: this.player.z + this.player.dir.z * 4 };
            } else if (g.id === 3 && Math.hypot(g.x - this.player.x, g.z - this.player.z) < 8) {
              target = g.homeCorner;
            }

            let best = valid[0], minDist = Infinity;
            valid.forEach(d => {
              const dist = Math.hypot((tileX + d.x) - target.x, (tileZ + d.z) - target.z);
              if (dist < minDist) { minDist = dist; best = d; }
            });
            g.dir = best;
          }
        }

        g.x += g.dir.x * step;
        g.z += g.dir.z * step;
      }

      const worldX = (g.x - PCXMap.COLS / 2 + 0.5) * PCXMap.TILE;
      const worldZ = (g.z - PCXMap.ROWS / 2 + 0.5) * PCXMap.TILE;
      g.mesh.position.set(worldX, 0.72 + Math.sin(Date.now() * 0.008 + g.id) * 0.08, worldZ);

      const pOffsetX = g.dir.x * 0.06;
      const pOffsetZ = g.dir.z * 0.06;
      g.mesh.leftPupil.position.x = -0.25 + pOffsetX;
      g.mesh.leftPupil.position.z = 0.68 + pOffsetZ;
      g.mesh.rightPupil.position.x = 0.25 + pOffsetX;
      g.mesh.rightPupil.position.z = 0.68 + pOffsetZ;

      if (Math.hypot(g.x - this.player.x, g.z - this.player.z) < 0.75) {
        if (g.frightenedTimer > 0) {
          this.score += 200;
          this.audio.playGhostEaten();
          this.particles.spawnBurst(worldX, 0.8, worldZ, 'purple', 20);
          g.state = 'HOUSE';
          g.houseTimer = 240;
          g.frightenedTimer = 0;
          g.x = 13.5; g.z = 14;
          g.mesh.bodyMat.color.setHex(g.originalColor);
          this.updateHUD();
        } else {
          this.triggerDeath();
        }
      }
    });
  }

  triggerDeath() {
    this.audio.playDeath();
    if (this.singularityShards > 0 && this.timelineHistory.length > 60) {
      this.openRewind();
    } else {
      this.lives--;
      this.updateHUD();
      if (this.lives <= 0) {
        this.gameState = 'GAMEOVER';
        document.getElementById('banner-title').innerText = 'SINGULARITY COLLAPSE';
        document.getElementById('banner-subtitle').innerText = 'Consciousness decoherence. High score saved.';
        document.getElementById('btn-start').innerText = 'REBOOT SYSTEM [SPACE]';
        document.getElementById('center-banner').style.display = 'block';
      } else {
        this.resetEntities();
      }
    }
  }

  openRewind() {
    this.gameState = 'REWIND_OFFER';
    let countdown = 5.0;
    const modal = document.getElementById('rewind-modal');
    const timerLabel = document.getElementById('rewind-timer');
    modal.style.display = 'flex';
    timerLabel.innerText = '5.00s';

    this.rewindInterval = setInterval(() => {
      countdown -= 0.05;
      if (countdown <= 0) {
        clearInterval(this.rewindInterval);
        this.declineRewind();
      } else {
        timerLabel.innerText = countdown.toFixed(2) + 's';
      }
    }, 50);
  }

  executeRewind() {
    clearInterval(this.rewindInterval);
    document.getElementById('rewind-modal').style.display = 'none';
    this.singularityShards--;
    this.audio.playDopplerRewind();
    this.updateHUD();

    this.gameState = 'REWINDING';
    let frames = Math.min(this.timelineHistory.length, 180);

    const rewindStep = () => {
      if (frames > 0 && this.timelineHistory.length > 0) {
        const snap = this.timelineHistory.pop();
        this.player.x = snap.player.x;
        this.player.z = snap.player.z;
        this.player.dir = snap.player.dir;
        this.player.bufferDir = snap.player.bufferDir;

        snap.ghosts.forEach((gSnap, i) => {
          this.ghosts[i].x = gSnap.x;
          this.ghosts[i].z = gSnap.z;
          this.ghosts[i].dir = gSnap.dir;
          this.ghosts[i].state = gSnap.state;
        });

        const worldX = (this.player.x - PCXMap.COLS / 2 + 0.5) * PCXMap.TILE;
        const worldZ = (this.player.z - PCXMap.ROWS / 2 + 0.5) * PCXMap.TILE;
        this.playerMesh.position.set(worldX, 0.72, worldZ);
        this.ghosts.forEach(g => {
          g.mesh.position.set((g.x - PCXMap.COLS / 2 + 0.5) * PCXMap.TILE, 0.72, (g.z - PCXMap.ROWS / 2 + 0.5) * PCXMap.TILE);
        });

        frames -= 4;
        requestAnimationFrame(rewindStep);
      } else {
        this.gameState = 'RUNNING';
      }
    };
    rewindStep();
  }

  declineRewind() {
    clearInterval(this.rewindInterval);
    document.getElementById('rewind-modal').style.display = 'none';
    this.lives--;
    this.updateHUD();
    if (this.lives <= 0) {
      this.gameState = 'GAMEOVER';
      document.getElementById('banner-title').innerText = 'SINGULARITY COLLAPSE';
      document.getElementById('banner-subtitle').innerText = 'Game Over. Your record is etched into memory.';
      document.getElementById('btn-start').innerText = 'REBOOT SYSTEM [SPACE]';
      document.getElementById('center-banner').style.display = 'block';
    } else {
      this.resetEntities();
      this.gameState = 'RUNNING';
    }
  }

  resetEntities() {
    this.player.x = 13.5; this.player.z = 23.0;
    this.player.dir = { x: -1, z: 0 };
    this.player.bufferDir = { x: -1, z: 0 };
    this.ghosts.forEach((g, idx) => {
      g.x = g.startX; g.z = g.startZ;
      g.state = idx === 0 ? 'CHASE' : 'HOUSE';
      g.houseTimer = idx * 120;
      g.frightenedTimer = 0;
      g.mesh.bodyMat.color.setHex(g.originalColor);
    });
  }

  checkVictory() {
    const remaining = this.dots.some(d => d.active);
    if (!remaining) {
      this.gameState = 'LEVEL_CLEAR';
      document.getElementById('banner-title').innerText = 'MANIFOLD PURIFIED!';
      document.getElementById('banner-subtitle').innerText = `Level ${this.level} Cleared. Advancing to Quantum Sector ${this.level + 1}.`;
      document.getElementById('btn-start').innerText = 'PROCEED TO SECTOR ' + (this.level + 1);
      document.getElementById('center-banner').style.display = 'block';
    }
  }

  updateHUD() {
    document.getElementById('ui-score').innerText = String(this.score).padStart(5, '0');
    document.getElementById('ui-highscore').innerText = String(this.highScore).padStart(5, '0');
    document.getElementById('ui-level').innerText = String(this.level).padStart(2, '0');
    document.getElementById('ui-shards').innerText = `${this.singularityShards} SHARD${this.singularityShards === 1 ? '' : 'S'}`;

    let livesHtml = '';
    for (let i = 0; i < this.lives; i++) livesHtml += '<span style="color:#ffe600; font-size:1.1rem;">●</span> ';
    document.getElementById('ui-lives').innerHTML = livesHtml || '<span style="color:#ef4444; font-size:0.75rem;">CRITICAL</span>';
  }

  loop(now) {
    requestAnimationFrame((t) => this.loop(t));
    const dt = Math.min((now - this.lastTime) / 1000, 0.1);
    const dtFactor = dt * 60.0;
    this.lastTime = now;

    this.dots.forEach(d => {
      if (d.active && d.isEnergizer) {
        d.mesh.rotation.y += 0.04 * dtFactor;
        d.mesh.rotation.x += 0.02 * dtFactor;
      }
    });

    if (this.gameState === 'RUNNING') {
      this.updatePlayerPhysics(dtFactor);
      this.updateGhostAI(dtFactor);
      this.particles.update(dtFactor);

      this.timelineHistory.push({
        player: { x: this.player.x, z: this.player.z, dir: { ...this.player.dir }, bufferDir: { ...this.player.bufferDir } },
        ghosts: this.ghosts.map(g => ({ x: g.x, z: g.z, dir: { ...g.dir }, state: g.state })),
        score: this.score
      });
      if (this.timelineHistory.length > this.MAX_HISTORY) this.timelineHistory.shift();

      const activeDots = this.dots.filter(d => d.active).length;
      this.audio.updateSiren(true, this.frightenedTimer > 0, activeDots / this.dots.length);
    } else {
      this.audio.updateSiren(false, false);
    }

    this.renderer.updateCamera(this.playerMesh.position, this.player.dir);
    this.renderer.render();
  }
}

window.addEventListener('DOMContentLoaded', () => {
  window.gameInstance = new PCXGame();
});
