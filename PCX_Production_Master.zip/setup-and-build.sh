#!/usr/bin/env bash
# ==============================================================================
# PCX // Headless Codespaces & Remote Linux Android APK Build Pipeline
# Hardened for non-interactive automated environments
# ==============================================================================
set -e

echo ">>> [1/5] Checking Node.js, NPM, and Java 17..."
if ! command -v node &> /dev/null; then
  echo "Installing Node.js 20..."
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi

if ! command -v javac &> /dev/null; then
  echo "Installing OpenJDK 17..."
  sudo apt-get update && sudo apt-get install -y openjdk-17-jdk wget unzip
fi

echo ">>> [2/5] Setting up Android SDK Command-Line Tools..."
export ANDROID_HOME=$HOME/android-sdk
export ANDROID_SDK_ROOT=$HOME/android-sdk
mkdir -p $ANDROID_HOME/cmdline-tools

if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  echo "Downloading Android SDK Command-Line Tools..."
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O /tmp/cmdline-tools.zip
  unzip -q /tmp/cmdline-tools.zip -d $ANDROID_HOME/cmdline-tools
  mv $ANDROID_HOME/cmdline-tools/cmdline-tools $ANDROID_HOME/cmdline-tools/latest
  rm -f /tmp/cmdline-tools.zip
fi

export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools
yes | sdkmanager --licenses > /dev/null 2>&1 || true

echo "Installing platforms and build-tools (API 34)..."
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" > /dev/null

echo ">>> [3/5] Installing Capacitor dependencies & bundling web assets..."
npm install
npm run build

echo ">>> [4/5] Initializing Capacitor Android Platform..."
if [ ! -d "android" ]; then
  npx cap add android
fi
npx cap sync android

echo ">>> [5/5] Compiling Native Debug APK via Gradle..."
cd android
chmod +x ./gradlew
./gradlew assembleDebug

echo "===================================================================="
echo "✔ BUILD SUCCESSFUL!"
echo "Your installable APK is located at:"
echo "  $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
echo "===================================================================="
